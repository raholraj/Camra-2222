/*
 * Copyright (C) 2025 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.google.jetpackcamera

import androidx.compose.ui.test.junit4.createEmptyComposeRule
import androidx.compose.ui.test.onNodeWithTag
import androidx.compose.ui.test.performClick
import androidx.compose.ui.test.performTextInput
import androidx.test.ext.junit.runners.AndroidJUnit4
import androidx.test.platform.app.InstrumentationRegistry
import androidx.test.rule.GrantPermissionRule
import androidx.test.uiautomator.UiDevice
import com.google.common.truth.Truth.assertThat
import com.google.jetpackcamera.ui.components.capture.AUDIO_INPUT_TOGGLE
import com.google.jetpackcamera.ui.components.capture.CAPTURE_BUTTON
import com.google.jetpackcamera.ui.components.capture.FLIP_CAMERA_BUTTON
import com.google.jetpackcamera.ui.components.capture.ZOOM_BUTTON_ROW_TAG
import com.google.jetpackcamera.ui.debug.BTN_DEBUG_HIDE_COMPONENTS_TAG
import com.google.jetpackcamera.ui.debug.DEBUG_OVERLAY_BUTTON
import com.google.jetpackcamera.ui.debug.DEBUG_OVERLAY_SET_ZOOM_RATIO_BUTTON
import com.google.jetpackcamera.ui.debug.DEBUG_OVERLAY_SET_ZOOM_RATIO_SET_BUTTON
import com.google.jetpackcamera.ui.debug.DEBUG_OVERLAY_SET_ZOOM_RATIO_TEXT_FIELD
import com.google.jetpackcamera.ui.debug.LOGICAL_CAMERA_ID_TAG
import com.google.jetpackcamera.ui.debug.PHYSICAL_CAMERA_ID_TAG
import com.google.jetpackcamera.ui.debug.ZOOM_RATIO_TAG
import com.google.jetpackcamera.utils.TEST_REQUIRED_PERMISSIONS
import com.google.jetpackcamera.utils.debugExtra
import com.google.jetpackcamera.utils.runMainActivityScenarioTest
import com.google.jetpackcamera.utils.waitForCaptureButton
import com.google.jetpackcamera.utils.waitForNodeWithTag
import com.google.jetpackcamera.utils.waitForNodeWithTagToDisappear
import org.junit.Before
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith

@RunWith(AndroidJUnit4::class)
class DebugOverlayTest {
    @get:Rule
    val permissionsRule: GrantPermissionRule =
        GrantPermissionRule.grant(*(TEST_REQUIRED_PERMISSIONS).toTypedArray())

    @get:Rule
    val composeTestRule = createEmptyComposeRule()

    private val uiDevice = UiDevice.getInstance(InstrumentationRegistry.getInstrumentation())

    @Before
    fun setUp() {
        assertThat(uiDevice.isScreenOn).isTrue()
    }

    @Test
    fun hideComponentsButton_togglesUiVisibility() {
        runMainActivityScenarioTest(debugExtra) {
            composeTestRule.waitForCaptureButton()
            composeTestRule.onNodeWithTag(CAPTURE_BUTTON).assertExists()
            composeTestRule.onNodeWithTag(FLIP_CAMERA_BUTTON).assertExists()
            composeTestRule.onNodeWithTag(DEBUG_OVERLAY_BUTTON).assertExists()
            composeTestRule.onNodeWithTag(LOGICAL_CAMERA_ID_TAG).assertExists()
            composeTestRule.onNodeWithTag(PHYSICAL_CAMERA_ID_TAG).assertExists()
            composeTestRule.onNodeWithTag(ZOOM_RATIO_TAG).assertExists()

            composeTestRule.onNodeWithTag(BTN_DEBUG_HIDE_COMPONENTS_TAG).performClick()

            composeTestRule.waitForNodeWithTagToDisappear(CAPTURE_BUTTON)
            composeTestRule.onNodeWithTag(ZOOM_BUTTON_ROW_TAG).assertDoesNotExist()
            composeTestRule.onNodeWithTag(FLIP_CAMERA_BUTTON).assertDoesNotExist()
            composeTestRule.onNodeWithTag(AUDIO_INPUT_TOGGLE).assertDoesNotExist()
            composeTestRule.onNodeWithTag(DEBUG_OVERLAY_BUTTON).assertDoesNotExist()
            composeTestRule.onNodeWithTag(LOGICAL_CAMERA_ID_TAG).assertDoesNotExist()
            composeTestRule.onNodeWithTag(PHYSICAL_CAMERA_ID_TAG).assertDoesNotExist()
            composeTestRule.onNodeWithTag(ZOOM_RATIO_TAG).assertDoesNotExist()

            composeTestRule.onNodeWithTag(BTN_DEBUG_HIDE_COMPONENTS_TAG).performClick()

            composeTestRule.waitForNodeWithTag(CAPTURE_BUTTON)
            composeTestRule.onNodeWithTag(FLIP_CAMERA_BUTTON).assertExists()
            composeTestRule.onNodeWithTag(DEBUG_OVERLAY_BUTTON).assertExists()
            composeTestRule.onNodeWithTag(LOGICAL_CAMERA_ID_TAG).assertExists()
            composeTestRule.onNodeWithTag(PHYSICAL_CAMERA_ID_TAG).assertExists()
            composeTestRule.onNodeWithTag(ZOOM_RATIO_TAG).assertExists()
        }
    }

    @Test
    fun setZoomRatio_viaDebugOverlay() {
        runMainActivityScenarioTest(debugExtra) {
            composeTestRule.waitForCaptureButton()

            // Open debug menu
            composeTestRule.onNodeWithTag(DEBUG_OVERLAY_BUTTON).performClick()

            // Click "Set Zoom Ratio" button
            composeTestRule.waitForNodeWithTag(DEBUG_OVERLAY_SET_ZOOM_RATIO_BUTTON)
            composeTestRule.onNodeWithTag(DEBUG_OVERLAY_SET_ZOOM_RATIO_BUTTON).performClick()

            // Find text field and enter value
            composeTestRule.waitForNodeWithTag(DEBUG_OVERLAY_SET_ZOOM_RATIO_TEXT_FIELD)
            composeTestRule.onNodeWithTag(
                DEBUG_OVERLAY_SET_ZOOM_RATIO_TEXT_FIELD
            ).performTextInput("1.5")

            // Click "Confirm"
            composeTestRule.onNodeWithTag(DEBUG_OVERLAY_SET_ZOOM_RATIO_SET_BUTTON).performClick()

            // Verify dialog closed (text field should not exist anymore)
            composeTestRule.onNodeWithTag(
                DEBUG_OVERLAY_SET_ZOOM_RATIO_TEXT_FIELD
            ).assertDoesNotExist()

            // Verify zoom ratio text exists
            composeTestRule.onNodeWithTag(ZOOM_RATIO_TAG).assertExists()
        }
    }
}
