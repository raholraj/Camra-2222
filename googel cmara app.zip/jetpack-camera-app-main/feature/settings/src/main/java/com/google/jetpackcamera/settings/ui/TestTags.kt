/*
 * Copyright (C) 2024 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.google.jetpackcamera.settings.ui

// ////////////////////////////////
//
// !!!HEY YOU!!!
// MODIFICATIONS TO EXISTING TEST TAGS WILL BREAK EXISTING EXTERNAL
// AUTOMATED TESTS THAT SEARCH FOR THESE TAGS.
//
// PLEASE UPDATE YOUR TESTS ACCORDINGLY!
//
// ////////////////////////////////

const val SETTINGS_TITLE = "SettingsTitle"
const val BACK_BUTTON = "BackButton"
const val CLOSE_BUTTON = "CloseButton"
const val CONTAINER_DIALOG_CONTENTS = "dialog_contents_container"

// unsupported rationale tags
const val DEVICE_UNSUPPORTED_TAG = "DeviceUnsupportedTag"
const val STABILIZATION_UNSUPPORTED_TAG = "StabilizationUnsupportedTag"
const val LENS_UNSUPPORTED_TAG = "LensUnsupportedTag"
const val FPS_UNSUPPORTED_TAG = "FpsUnsupportedTag"
const val VIDEO_QUALITY_UNSUPPORTED_TAG = "VideoQualityUnsupportedTag"
const val PERMISSION_RECORD_AUDIO_NOT_GRANTED_TAG = "PermissionRecordAudioNotGrantedTag"
const val CAPTURE_MODE_UNSUPPORTED_TAG = "CaptureModeUnsupportedTag"
const val STREAM_CONFIG_UNSUPPORTED_TAG = "StreamConfigUnsupportedTag"
const val FLASH_LLB_UNSUPPORTED_TAG = "FlashLlbUnsupportedTag"
const val HDR_UNSUPPORTED_TAG = "HdrUnsupportedTag"
const val CONCURRENT_CAMERA_ENABLED_TAG = "ConcurrentCameraEnabledTag"
const val CONCURRENT_CAMERA_STREAM_CONFIG_TAG = "ConcurrentCameraStreamConfigTag"
const val STABILIZATION_ACTIVE_TAG = "StabilizationActiveTag"
const val FIXED_FPS_ACTIVE_TAG = "FixedFpsActiveTag"
const val FLASH_LLB_ACTIVE_TAG = "FlashLlbActiveTag"
const val HDR_ACTIVE_TAG = "HdrActiveTag"
const val ULTRA_HDR_ENABLED_TAG = "UltraHdrEnabledTag"

// Settings w/ no dialog
const val BTN_SWITCH_SETTING_LENS_FACING_TAG = "btn_switch_setting_lens_facing_tag"
const val BTN_SWITCH_SETTING_ENABLE_AUDIO_TAG = "btn_switch_setting_enable_audio_tag"
const val BTN_SWITCH_SETTING_CONCURRENT_CAMERA_TAG = "btn_switch_setting_concurrent_camera_tag"
const val TEXT_SETTING_APP_VERSION_TAG = "text_setting_app_version_tag"

// Flash Mode
const val BTN_OPEN_DIALOG_SETTING_FLASH_TAG = "btn_open_dialog_setting_flash_tag"
const val BTN_DIALOG_FLASH_OPTION_AUTO_TAG = "btn_dialog_flash_option_auto_tag"
const val BTN_DIALOG_FLASH_OPTION_ON_TAG = "btn_dialog_flash_option_on_tag"
const val BTN_DIALOG_FLASH_OPTION_OFF_TAG = "btn_dialog_flash_option_off_tag"
const val BTN_DIALOG_FLASH_OPTION_LLB_TAG = "btn_dialog_flash_option_llb_tag"

// Frame Rate
const val BTN_OPEN_DIALOG_SETTING_FPS_TAG = "btn_open_dialog_setting_fps_tag"
const val BTN_DIALOG_FPS_OPTION_AUTO_TAG = "btn_dialog_fps_option_auto_tag"
const val BTN_DIALOG_FPS_OPTION_15_TAG = "btn_dialog_fps_option_15_tag"
const val BTN_DIALOG_FPS_OPTION_30_TAG = "btn_dialog_fps_option_30_tag"
const val BTN_DIALOG_FPS_OPTION_60_TAG = "btn_dialog_fps_option_60_tag"

// Aspect Ratio
const val BTN_OPEN_DIALOG_SETTING_ASPECT_RATIO_TAG = "btn_open_dialog_setting_aspect_ratio_tag"
const val BTN_DIALOG_ASPECT_RATIO_OPTION_9_16_TAG = "btn_dialog_aspect_ratio_option_9_16_tag"
const val BTN_DIALOG_ASPECT_RATIO_OPTION_3_4_TAG = "btn_dialog_aspect_ratio_option_3_4_tag"
const val BTN_DIALOG_ASPECT_RATIO_OPTION_1_1_TAG = "btn_dialog_aspect_ratio_option_1_1_tag"

// Stream Configuration
const val BTN_OPEN_DIALOG_SETTING_STREAM_CONFIG_TAG = "btn_open_dialog_setting_stream_config_tag"
const val BTN_DIALOG_STREAM_CONFIG_OPTION_SINGLE_STREAM_TAG =
    "btn_dialog_stream_config_option_single_stream_tag"
const val BTN_DIALOG_STREAM_CONFIG_OPTION_MULTI_STREAM_CAPTURE_TAG =
    "btn_dialog_stream_config_option_multi_stream_capture_tag"

// Low Light Boost Priority
const val BTN_OPEN_DIALOG_SETTING_LOW_LIGHT_BOOST_PRIORITY_TAG =
    "btn_open_dialog_setting_low_light_boost_priority_tag"
const val BTN_DIALOG_LOW_LIGHT_BOOST_PRIORITY_OPTION_AE_MODE_TAG =
    "btn_dialog_low_light_boost_priority_option_ae_mode_tag"
const val BTN_DIALOG_LOW_LIGHT_BOOST_PRIORITY_OPTION_GOOGLE_PLAY_SERVICES_TAG =
    "btn_dialog_low_light_boost_priority_option_google_play_services_tag"

// Max Video Duration
const val BTN_OPEN_DIALOG_SETTING_VIDEO_DURATION_TAG = "btn_open_dialog_setting_video_duration_tag"
const val BTN_DIALOG_VIDEO_DURATION_OPTION_UNLIMITED_TAG =
    "btn_dialog_video_duration_option_unlimited_tag"
const val BTN_DIALOG_VIDEO_DURATION_OPTION_1S_TAG = "btn_dialog_video_duration_option_1s_tag"
const val BTN_DIALOG_VIDEO_DURATION_OPTION_10S_TAG = "btn_dialog_video_duration_option_10s_tag"
const val BTN_DIALOG_VIDEO_DURATION_OPTION_30S_TAG = "btn_dialog_video_duration_option_30s_tag"
const val BTN_DIALOG_VIDEO_DURATION_OPTION_60S_TAG = "btn_dialog_video_duration_option_60s_tag"

// Video Stabilization
const val BTN_OPEN_DIALOG_SETTING_VIDEO_STABILIZATION_TAG =
    "btn_open_dialog_setting_video_stabilization_tag"
const val BTN_DIALOG_VIDEO_STABILIZATION_OPTION_AUTO_TAG =
    "btn_dialog_video_stabilization_option_auto_tag"
const val BTN_DIALOG_VIDEO_STABILIZATION_OPTION_ON_TAG =
    "btn_dialog_video_stabilization_option_on_tag"
const val BTN_DIALOG_VIDEO_STABILIZATION_OPTION_OFF_TAG =
    "btn_dialog_video_stabilization_option_off_tag"
const val BTN_DIALOG_VIDEO_STABILIZATION_OPTION_HIGH_QUALITY_TAG =
    "btn_dialog_video_stabilization_option_high_quality_tag"
const val BTN_DIALOG_VIDEO_STABILIZATION_OPTION_OPTICAL_TAG =
    "btn_dialog_video_stabilization_option_optical_tag"

// Video Quality
const val BTN_OPEN_DIALOG_SETTING_VIDEO_QUALITY_TAG = "btn_open_dialog_setting_video_quality_tag"
const val BTN_DIALOG_VIDEO_QUALITY_OPTION_UNSPECIFIED_TAG =
    "btn_dialog_video_quality_option_unspecified_tag"
const val BTN_DIALOG_VIDEO_QUALITY_OPTION_SD_TAG = "btn_dialog_video_quality_option_sd_tag"
const val BTN_DIALOG_VIDEO_QUALITY_OPTION_HD_TAG = "btn_dialog_video_quality_option_hd_tag"
const val BTN_DIALOG_VIDEO_QUALITY_OPTION_FHD_TAG = "btn_dialog_video_quality_option_fhd_tag"
const val BTN_DIALOG_VIDEO_QUALITY_OPTION_UHD_TAG = "btn_dialog_video_quality_option_uhd_tag"

// Dark Mode
const val BTN_OPEN_DIALOG_SETTING_DARK_MODE_TAG = "btn_open_dialog_setting_dark_mode_tag"
const val BTN_DIALOG_DARK_MODE_OPTION_ON_TAG = "btn_dialog_dark_mode_option_on_tag"
const val BTN_DIALOG_DARK_MODE_OPTION_OFF_TAG = "btn_dialog_dark_mode_option_off_tag"
const val BTN_DIALOG_DARK_MODE_OPTION_SYSTEM_TAG = "btn_dialog_dark_mode_option_system_tag"
