/*
 * Copyright (C) 2025 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.google.jetpackcamera.feature.postcapture.ui

const val BUTTON_POST_CAPTURE_EXIT = "btn_post_capture_exit"
const val BUTTON_POST_CAPTURE_SAVE = "btn_post_capture_save"

const val BUTTON_POST_CAPTURE_SHARE = "btn_post_capture_share"

const val BUTTON_POST_CAPTURE_DELETE = "btn_post_capture_delete"
const val VIEWER_POST_CAPTURE_VIDEO = "viewer_post_capture_video"
const val VIEWER_POST_CAPTURE_IMAGE = "viewer_post_capture_image"
