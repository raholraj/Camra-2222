package com.google.jetpackcamera.feature.preview.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import kotlin.math.roundToInt

@Composable
fun DraggablePipOverlay(
    modifier: Modifier = Modifier,
    content: @Composable () -> Unit
) {
    val configuration = LocalConfiguration.current
    val screenWidth = configuration.screenWidthDp.dp

    // Constraints: 15% to 45% of screen width
    val minSize = screenWidth * 0.15f
    val maxSize = screenWidth * 0.45f
    
    var scale by remember { mutableFloatStateOf(1f) }
    var offsetX by remember { mutableFloatStateOf(50f) }
    var offsetY by remember { mutableFloatStateOf(50f) }
    var currentSize by remember { mutableStateOf(screenWidth * 0.28f) }

    Box(
        modifier = modifier
            .offset { IntOffset(offsetX.roundToInt(), offsetY.roundToInt()) }
            .size(currentSize * scale)
            .clip(RoundedCornerShape(12.dp))
            .border(2.dp, Color.White, RoundedCornerShape(12.dp))
            .background(Color.Black)
            .pointerInput(Unit) {
                detectTransformGestures { _, pan, zoom, _ ->
                    // Handle Resize
                    scale = (scale * zoom).coerceIn(
                        minimumValue = minSize.value / currentSize.value,
                        maximumValue = maxSize.value / currentSize.value
                    )
                    // Handle Drag
                    offsetX += pan.x
                    offsetY += pan.y
                }
            }
    ) {
        // Here you pass the Secondary Camera Preview (AndroidView)
        content()
    }
}
