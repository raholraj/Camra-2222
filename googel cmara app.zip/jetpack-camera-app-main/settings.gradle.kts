/*
 * Copyright (C) 2023 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

pluginManagement {
    repositories {
        google()
        mavenCentral()
        gradlePluginPortal()
    }
}
@Suppress("UnstableApiUsage")
dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        maven {
            setUrl("https://androidx.dev/snapshots/latest/artifacts/repository")
        }
        google()
        mavenCentral()
    }
}
rootProject.name = "Jetpack Camera"
include(":app")
include(":feature:preview")
include(":core:camera")
include(":data:camera")
include(":core:camera:testing")
include(":core:camera:low-light")
include(":core:camera:low-light-playservices")
include(":core:camera:effects:single-stream")
include(":feature:settings")
include(":data:settings")
include(":data:settings:testing")
include(":data:media")
include(":data:media:testing")
include(":core:common")
include(":core:common:testing")
include(":benchmark")
include(":feature:permissions")
include(":feature:postcapture")
include(":ui:uistate")
include(":ui:uistateadapter")
include(":ui:uistate:capture")
include(":ui:uistateadapter:capture")
include(":ui:components")
include(":ui:components:capture")
include(":data:model")
include(":core:settings")
include(":core:model")
include(":ui:uistate:postcapture")
include(":ui:uistateadapter:postcapture")
include(":core:camera:postprocess")
include(":ui:controller")
include(":ui:controller:impl")
include(":ui:controller:testing")
include(":core:settings:datastore-prefs")
include(":core:settings:datastore-prefs:testing")
include(":ui:debug")
include(":ui:debug:testing")
