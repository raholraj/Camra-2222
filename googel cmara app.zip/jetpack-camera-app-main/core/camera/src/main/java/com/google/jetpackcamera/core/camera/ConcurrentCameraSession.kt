package com.google.jetpackcamera.core.camera

import androidx.camera.core.ConcurrentCamera
import androidx.camera.core.UseCaseGroup
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.lifecycle.LifecycleOwner
import com.google.jetpackcamera.model.DualCameraRecordingMode

class ConcurrentCameraSession(
    private val cameraProvider: ProcessCameraProvider,
    private val lifecycleOwner: LifecycleOwner
) {
    // Check if device supports concurrent cameras
    fun isConcurrentCameraSupported(): Boolean {
        return cameraProvider.availableConcurrentCameraInfos.isNotEmpty()
    }

    fun bindDualCameras(
        primaryUseCaseGroup: UseCaseGroup,
        secondaryUseCaseGroup: UseCaseGroup,
        mode: DualCameraRecordingMode
    ) {
        if (!isConcurrentCameraSupported() || mode == DualCameraRecordingMode.SINGLE) return

        val concurrentCameraInfos = cameraProvider.availableConcurrentCameraInfos.firstOrNull() 
            ?: return

        val primaryCameraInfo = concurrentCameraInfos.first { it.lensFacing == androidx.camera.core.CameraSelector.LENS_FACING_BACK }
        val secondaryCameraInfo = concurrentCameraInfos.first { it.lensFacing == androidx.camera.core.CameraSelector.LENS_FACING_FRONT }

        val primarySelector = primaryCameraInfo.cameraSelector
        val secondarySelector = secondaryCameraInfo.cameraSelector

        val primaryConfig = ConcurrentCamera.SingleCameraConfig(
            primarySelector,
            primaryUseCaseGroup,
            lifecycleOwner
        )
        val secondaryConfig = ConcurrentCamera.SingleCameraConfig(
            secondarySelector,
            secondaryUseCaseGroup,
            lifecycleOwner
        )

        // Bind both cameras simultaneously
        cameraProvider.bindToLifecycle(listOf(primaryConfig, secondaryConfig))
    }
}
