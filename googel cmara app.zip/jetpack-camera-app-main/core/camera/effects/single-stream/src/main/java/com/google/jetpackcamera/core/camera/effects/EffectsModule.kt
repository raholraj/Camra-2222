/*
 * Copyright (C) 2026 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.google.jetpackcamera.core.camera.effects

import com.google.jetpackcamera.core.camera.CameraEffectProvider
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent
import dagger.multibindings.IntoSet
import java.util.AbstractMap
import javax.inject.Provider

/**
 * Hilt module to bind [SingleStreamEffectProvider] in the [SingletonComponent].
 */
@Module
@InstallIn(SingletonComponent::class)
internal object EffectsModule {
    @Provides
    @IntoSet
    fun provideSingleStreamEffectProviderEntry(
        impl: Provider<SingleStreamEffectProvider>
    ): Map.Entry<
        CameraEffectFeatureKey,
        @JvmSuppressWildcards Provider<CameraEffectProvider>
        > =
        AbstractMap.SimpleImmutableEntry(
            SingleStreamEffectKey,
            Provider { impl.get() }
        )
}
