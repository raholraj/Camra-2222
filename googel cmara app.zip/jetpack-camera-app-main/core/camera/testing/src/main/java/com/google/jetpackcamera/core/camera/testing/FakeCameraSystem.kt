/*
 * Copyright (C) 2023 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.google.jetpackcamera.core.camera.testing

import android.annotation.SuppressLint
import android.content.ContentResolver
import androidx.camera.core.ImageCapture
import androidx.camera.core.SurfaceRequest
import com.google.jetpackcamera.core.camera.CameraState
import com.google.jetpackcamera.core.camera.CameraSystem
import com.google.jetpackcamera.core.camera.OnVideoRecordEvent
import com.google.jetpackcamera.model.AspectRatio
import com.google.jetpackcamera.model.CameraEffectId
import com.google.jetpackcamera.model.CameraZoomRatio
import com.google.jetpackcamera.model.CaptureMode
import com.google.jetpackcamera.model.ConcurrentCameraMode
import com.google.jetpackcamera.model.DeviceRotation
import com.google.jetpackcamera.model.DynamicRange
import com.google.jetpackcamera.model.FlashMode
import com.google.jetpackcamera.model.ImageOutputFormat
import com.google.jetpackcamera.model.LensFacing
import com.google.jetpackcamera.model.LowLightBoostPriority
import com.google.jetpackcamera.model.SaveLocation
import com.google.jetpackcamera.model.StabilizationMode
import com.google.jetpackcamera.model.TestPattern
import com.google.jetpackcamera.model.VideoQuality
import com.google.jetpackcamera.settings.model.CameraAppSettings
import com.google.jetpackcamera.settings.model.CameraSystemConstraints
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.channels.Channel.Factory.UNLIMITED
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.flow.onCompletion
import kotlinx.coroutines.flow.update

class FakeCameraSystem(defaultCameraSettings: CameraAppSettings = CameraAppSettings()) :
    CameraSystem {
    private val availableLenses = listOf(LensFacing.FRONT, LensFacing.BACK)
    private var initialized = false
    private var useCasesBinded = false

    var previewStarted = false
    var numPicturesTaken = 0

    var recordingInProgress = false
    var isRecordingPaused = false

    var isLensFacingFront = false

    private var isScreenFlash = true
    private var screenFlashEvents = Channel<CameraSystem.ScreenFlashEvent>(capacity = UNLIMITED)
    private val zoomChanges = MutableStateFlow<CameraZoomRatio?>(null)
    private val currentSettings = MutableStateFlow(defaultCameraSettings)

    override suspend fun initialize(
        cameraAppSettings: CameraAppSettings,
        cameraPropertiesJSONCallback: (result: String) -> Unit
    ) {
        initialized = true
    }

    override suspend fun runCamera() {
        val lensFacing = currentSettings.value.cameraLensFacing

        if (!initialized) {
            throw IllegalStateException("CameraProvider not initialized")
        }
        if (!availableLenses.contains(lensFacing)) {
            throw IllegalStateException("Requested lens not available")
        }

        currentSettings
            .onCompletion {
                useCasesBinded = false
                previewStarted = false
                recordingInProgress = false
            }.collectLatest {
                useCasesBinded = true
                previewStarted = true

                isLensFacingFront = it.cameraLensFacing == LensFacing.FRONT
                isScreenFlash =
                    isLensFacingFront &&
                    (it.flashMode == FlashMode.AUTO || it.flashMode == FlashMode.ON)
            }
    }

    override suspend fun takePicture(onCaptureStarted: (() -> Unit)) {
        if (!useCasesBinded) {
            throw IllegalStateException("Usecases not bound")
        }
        if (isScreenFlash) {
            screenFlashEvents.trySend(
                CameraSystem.ScreenFlashEvent(CameraSystem.ScreenFlashEvent.Type.APPLY_UI) { }
            )
            screenFlashEvents.trySend(
                CameraSystem.ScreenFlashEvent(CameraSystem.ScreenFlashEvent.Type.CLEAR_UI) { }
            )
        }
        numPicturesTaken += 1
    }

    @SuppressLint("RestrictedApi")
    override suspend fun takePicture(
        contentResolver: ContentResolver,
        saveLocation: SaveLocation,
        onCaptureStarted: () -> Unit
    ): ImageCapture.OutputFileResults {
        takePicture(onCaptureStarted)
        return ImageCapture.OutputFileResults(null)
    }

    fun emitScreenFlashEvent(event: CameraSystem.ScreenFlashEvent) {
        screenFlashEvents.trySend(event)
    }

    var numVideoRecordingStarts = 0

    override suspend fun startVideoRecording(
        saveLocation: SaveLocation,
        onVideoRecord: (OnVideoRecordEvent) -> Unit
    ) {
        if (!useCasesBinded) {
            throw IllegalStateException("Usecases not bound")
        }
        numVideoRecordingStarts++
        recordingInProgress = true
    }

    override suspend fun pauseVideoRecording() {
        isRecordingPaused = true
    }

    override suspend fun resumeVideoRecording() {
        isRecordingPaused = false
    }

    override suspend fun stopVideoRecording() {
        recordingInProgress = false
    }

    private val _currentCameraState = MutableStateFlow(CameraState())

    /**
     * Test-only method to manipulate the current camera state.
     * Use this to simulate changes in the camera's lifecycle or state (e.g., recording vs not recording)
     * during tests, triggering downstream observers.
     */
    fun setCurrentCameraState(cameraState: CameraState) {
        _currentCameraState.value = cameraState
    }
    override fun changeZoomRatio(newZoomState: CameraZoomRatio) {
        zoomChanges.update { newZoomState }
    }

    override fun setTestPattern(newTestPattern: TestPattern) {
        currentSettings.update { old ->
            old.copy(debugSettings = old.debugSettings.copy(testPattern = newTestPattern))
        }
    }

    override fun getCurrentCameraState(): StateFlow<CameraState> = _currentCameraState.asStateFlow()

    private val _systemConstraints = MutableStateFlow<CameraSystemConstraints?>(null)

    /**
     * Test-only method to manipulate the camera system constraints.
     * Use this to simulate different device capabilities (e.g., available lenses, flash support)
     * during tests, ensuring the UI adapts correctly.
     */
    fun setSystemConstraints(systemConstraints: CameraSystemConstraints?) {
        _systemConstraints.value = systemConstraints
    }
    override fun getSystemConstraints(): StateFlow<CameraSystemConstraints?> =
        _systemConstraints.asStateFlow()

    private val _surfaceRequest = MutableStateFlow<SurfaceRequest?>(null)
    override fun getSurfaceRequest(): StateFlow<SurfaceRequest?> = _surfaceRequest.asStateFlow()

    override fun getScreenFlashEvents() = screenFlashEvents
    override fun getCurrentSettings(): StateFlow<CameraAppSettings?> = currentSettings.asStateFlow()

    override fun setFlashMode(flashMode: FlashMode) {
        currentSettings.update { old ->
            old.copy(flashMode = flashMode)
        }
    }

    override fun isScreenFlashEnabled() = isScreenFlash

    fun isPreviewStarted() = previewStarted

    override suspend fun setAspectRatio(aspectRatio: AspectRatio) {
        currentSettings.update { old ->
            old.copy(aspectRatio = aspectRatio)
        }
    }

    override suspend fun setVideoQuality(videoQuality: VideoQuality) {
        currentSettings.update { old ->
            old.copy(videoQuality = videoQuality)
        }
    }

    override suspend fun setLowLightBoostPriority(lowLightBoostPriority: LowLightBoostPriority) {
        currentSettings.update { old ->
            old.copy(lowLightBoostPriority = lowLightBoostPriority)
        }
    }

    override suspend fun setLensFacing(lensFacing: LensFacing) {
        currentSettings.update { old ->
            old.copy(cameraLensFacing = lensFacing)
        }
    }

    override suspend fun tapToFocus(x: Float, y: Float) {
        TODO("Not yet implemented")
    }

    override suspend fun setCameraEffect(cameraEffect: CameraEffectId) {
        currentSettings.update { old ->
            old.copy(selectedCameraEffect = cameraEffect)
        }
    }

    override suspend fun setDynamicRange(dynamicRange: DynamicRange) {
        currentSettings.update { old ->
            old.copy(dynamicRange = dynamicRange)
        }
    }

    override fun setDeviceRotation(deviceRotation: DeviceRotation) {
        currentSettings.update { old ->
            old.copy(deviceRotation = deviceRotation)
        }
    }

    override suspend fun setConcurrentCameraMode(concurrentCameraMode: ConcurrentCameraMode) {
        currentSettings.update { old ->
            old.copy(concurrentCameraMode = concurrentCameraMode)
        }
    }

    override suspend fun setImageFormat(imageFormat: ImageOutputFormat) {
        currentSettings.update { old ->
            old.copy(imageFormat = imageFormat)
        }
    }

    override suspend fun setAudioEnabled(isAudioEnabled: Boolean) {
        currentSettings.update { old ->
            old.copy(audioEnabled = isAudioEnabled)
        }
    }

    override suspend fun setStabilizationMode(stabilizationMode: StabilizationMode) {
        currentSettings.update { old ->
            old.copy(stabilizationMode = stabilizationMode)
        }
    }

    override suspend fun setTargetFrameRate(targetFrameRate: Int) {
        currentSettings.update { old ->
            old.copy(targetFrameRate = targetFrameRate)
        }
    }

    override suspend fun setMaxVideoDuration(durationInMillis: Long) {
        currentSettings.update { old ->
            old.copy(maxVideoDurationMillis = durationInMillis)
        }
    }

    override suspend fun setCaptureMode(captureMode: CaptureMode) {
        currentSettings.update { old ->
            old.copy(captureMode = captureMode)
        }
    }
}
