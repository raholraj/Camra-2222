package com.google.jetpackcamera.model

enum class DualCameraRecordingMode {
    SINGLE,
    PICTURE_IN_PICTURE,
    SIDE_BY_SIDE,
    SEPARATE_FILES
}

data class DualCameraState(
    val mode: DualCameraRecordingMode = DualCameraRecordingMode.SINGLE,
    val isSecondaryCameraActive: Boolean = false
)
