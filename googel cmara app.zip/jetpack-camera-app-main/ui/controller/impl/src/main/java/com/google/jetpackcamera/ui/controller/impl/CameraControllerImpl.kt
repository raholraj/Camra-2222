/*
 * Copyright (C) 2026 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.google.jetpackcamera.ui.controller.impl

import android.os.SystemClock
import android.util.Log
import androidx.tracing.Trace
import com.google.jetpackcamera.core.camera.CameraSystem
import com.google.jetpackcamera.core.common.traceFirstFramePreview
import com.google.jetpackcamera.model.DeviceRotation
import com.google.jetpackcamera.ui.controller.CameraController
import com.google.jetpackcamera.ui.uistate.capture.compound.CaptureUiState
import kotlin.coroutines.CoroutineContext
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.CoroutineStart
import kotlinx.coroutines.Deferred
import kotlinx.coroutines.Job
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.transformWhile
import kotlinx.coroutines.job
import kotlinx.coroutines.launch

private const val TAG = "CameraControllerImpl"

/**
 * Implementation of [CameraController] that manages the camera lifecycle.
 *
 * @param initializationDeferred A [Deferred] that completes when the camera system is initialized.
 * @param captureUiState The [StateFlow] of the capture UI state.
 * @param coroutineContext The [CoroutineContext] for launching coroutines.
 * @param cameraSystem The [com.google.jetpackcamera.core.camera.CameraSystem] to interact with.
 */
class CameraControllerImpl(
    private val initializationDeferred: Deferred<Unit>,
    private val captureUiState: StateFlow<CaptureUiState>,
    private val cameraSystem: CameraSystem,
    coroutineContext: CoroutineContext
) : CameraController {
    private var runningCameraJob: Job? = null
    private val job = Job(parent = coroutineContext[Job])
    private val scope = CoroutineScope(coroutineContext + job)
    override fun startCamera() {
        Log.d(TAG, "startCamera")
        stopCamera()
        runningCameraJob = scope.launch {
            if (Trace.isEnabled()) {
                launch(start = CoroutineStart.UNDISPATCHED) {
                    val startTraceTimestamp: Long = SystemClock.elapsedRealtimeNanos()
                    traceFirstFramePreview(cookie = 1) {
                        captureUiState.transformWhile {
                            var continueCollecting = true
                            (it as? CaptureUiState.Ready)?.let { uiState ->
                                if (uiState.sessionFirstFrameTimestamp > startTraceTimestamp) {
                                    emit(Unit)
                                    continueCollecting = false
                                }
                            }
                            continueCollecting
                        }.collect {}
                    }
                }
            }
            // Ensure CameraSystem is initialized before starting camera
            initializationDeferred.await()
            // TODO(yasith): Handle Exceptions from binding use cases
            cameraSystem.runCamera()
        }
    }

    override fun stopCamera() {
        Log.d(TAG, "stopCamera")
        runningCameraJob?.apply {
            if (isActive) {
                cancel()
            }
        }
    }

    override fun tapToFocus(x: Float, y: Float) {
        Log.d(TAG, "tapToFocus")
        scope.launch {
            cameraSystem.tapToFocus(x, y)
        }
    }

    override fun setDisplayRotation(deviceRotation: DeviceRotation) {
        scope.launch {
            cameraSystem.setDeviceRotation(deviceRotation)
        }
    }

    /**
     * Initiates the cancellation of this controller's scope and returns its Job.
     * To wait for cancellation to complete, call .join() on the returned Job.
     */
    fun cancelScope(): Job {
        scope.cancel()
        return scope.coroutineContext.job
    }
}
